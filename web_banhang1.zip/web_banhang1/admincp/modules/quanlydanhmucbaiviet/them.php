<p>Thêm danh mục bài viết</p>
<table border="1" width="50%" style="border-collapse: collapse;">
 <form method="POST" action="modules/quanlydanhmucbaiviet/xuly.php">
	  <tr>
	  	<td>Tên danh mục bài viết</td>
	  	<td><input type="text" name="tendanhmucbaiviet"></td>
	  </tr>
	  <tr>
	    <td>Thứ tự</td>
	    <td><input type="text" name="thutu"></td>
	  </tr>
	   <tr>
	    <td colspan="2"><input type="submit" name="themdanhmucbaiviet" value="Thêm danh mục bài viết"></td>
	  </tr>
 </form>
</table>